import { NextRequest, NextResponse } from "next/server";
import { COMPANIES, DOMAINS, MCQS, TESTS, HR_QUESTIONS, DOMAIN_INTERVIEW_Q } from "@/lib/data";
export async function GET(req: NextRequest){
 const type = req.nextUrl.searchParams.get("type")||"all";
 const domain = req.nextUrl.searchParams.get("domain")||"";
 if(type==="companies") return NextResponse.json({companies:COMPANIES});
 if(type==="domains") return NextResponse.json({domains:DOMAINS});
 if(type==="tests") return NextResponse.json({tests:TESTS});
 if(type==="mcqs") return NextResponse.json({mcqs: domain? MCQS.filter(m=>m.domain===domain): MCQS});
 if(type==="questions"){
   const all=[...HR_QUESTIONS, ...Object.values(DOMAIN_INTERVIEW_Q).flat(), ...COMPANIES.flatMap(c=>c.questions.map(q=>({q:q.q,domain:q.type,company:c.name,type:q.type,difficulty:q.difficulty,keywords:q.keywords,sample:q.answer,tips:"From real "+c.name+" pattern — use keywords naturally."})))];
   return NextResponse.json({questions:all});
 }
 return NextResponse.json({companies:COMPANIES,domains:DOMAINS,tests:TESTS,totalMcqs:MCQS.length});
}
