import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { assessmentAttempts, interviewSessions, bookmarks, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { scoreAnswer, generateSWOC } from "@/lib/data";

export const runtime = "nodejs";
const number = (value: unknown, fallback=0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const percent = (value: unknown) => Math.max(0, Math.min(100, Math.round(number(value))));

async function registeredUser(userId:number){
 if(!userId) return false;
 const [user]=await db.select({id:users.id}).from(users).where(eq(users.id,userId)).limit(1);
 return Boolean(user);
}

export async function GET(req: NextRequest){
 try{
  const userId = number(req.nextUrl.searchParams.get("userId"));
  const [assessments,interviews,savedBookmarks,allAssessments,allInterviews] = await Promise.all([
    userId?db.select().from(assessmentAttempts).where(eq(assessmentAttempts.userId,userId)).orderBy(desc(assessmentAttempts.createdAt)).limit(30):Promise.resolve([]),
    userId?db.select().from(interviewSessions).where(eq(interviewSessions.userId,userId)).orderBy(desc(interviewSessions.createdAt)).limit(30):Promise.resolve([]),
    userId?db.select().from(bookmarks).where(eq(bookmarks.userId,userId)).orderBy(desc(bookmarks.createdAt)).limit(100):Promise.resolve([]),
    db.select().from(assessmentAttempts).orderBy(desc(assessmentAttempts.createdAt)).limit(100),
    db.select().from(interviewSessions).orderBy(desc(interviewSessions.createdAt)).limit(100),
  ]);
  const map=new Map<string,{name:string;points:number;tests:number;interviews:number}>();
  allAssessments.forEach(x=>{const k=x.userName||"Student";if(!map.has(k))map.set(k,{name:k,points:0,tests:0,interviews:0});const m=map.get(k)!;m.points+=x.score*10;m.tests++;});
  allInterviews.forEach(x=>{const k=x.userName||"Student";if(!map.has(k))map.set(k,{name:k,points:0,tests:0,interviews:0});const m=map.get(k)!;m.points+=x.overallScore*2;m.interviews++;});
  return NextResponse.json({assessments,interviews,bookmarks:savedBookmarks,leaderboard:[...map.values()].sort((a,b)=>b.points-a.points).slice(0,10),platform:{totalAttempts:allAssessments.length,totalInterviews:allInterviews.length}});
 }catch(error){
  console.error("Attempts read failure",error);
  return NextResponse.json({error:"Progress service unavailable",assessments:[],interviews:[],bookmarks:[],leaderboard:[],platform:{}},{status:503});
 }
}

export async function POST(req: NextRequest){
 try{
  const body=await req.json();
  if(body.kind==="score") return NextResponse.json({score:scoreAnswer(String(body.answer||""),Array.isArray(body.keywords)?body.keywords:[])});

  const userId=number(body.userId);
  const canSave=await registeredUser(userId);
  const userName=String(body.userName||"Student").slice(0,120);

  if(body.kind==="assessment"){
   if(!body.testId||!body.testTitle||!body.domain) return NextResponse.json({error:"Incomplete assessment data"},{status:400});
   const total=Math.max(1,Math.round(number(body.total,1))), score=Math.max(0,Math.min(total,Math.round(number(body.score))));
   const data={userId,userName,testId:String(body.testId).slice(0,80),testTitle:String(body.testTitle).slice(0,200),domain:String(body.domain).slice(0,100),score,total,accuracy:percent(body.accuracy),timeTakenSec:Math.max(0,Math.round(number(body.timeTakenSec))),details:Array.isArray(body.details)?body.details:[]};
   if(!canSave) return NextResponse.json({attempt:{...data,id:0,createdAt:new Date()},persisted:false,message:"Guest result calculated; sign up to save history."});
   const [attempt]=await db.insert(assessmentAttempts).values(data).returning(); return NextResponse.json({attempt,persisted:true},{status:201});
  }

  if(body.kind==="interview"){
   if(!body.domain) return NextResponse.json({error:"Interview domain is required"},{status:400});
   const metrics={keywordScore:percent(body.keywordScore),fluencyScore:percent(body.fluencyScore),confidenceScore:percent(body.confidenceScore),overallScore:percent(body.overallScore),fillerCount:Math.max(0,Math.round(number(body.fillerCount))),wpm:Math.max(0,Math.round(number(body.wpm)))};
   const domain=String(body.domain).slice(0,120),company=String(body.company||"General").slice(0,120);
   const swoc=generateSWOC({keyword:metrics.keywordScore,fluency:metrics.fluencyScore,confidence:metrics.confidenceScore,accuracy:metrics.keywordScore,filler:metrics.fillerCount,wpm:metrics.wpm,domain,company});
   const data={userId,userName,domain,company,mode:String(body.mode||"voice").slice(0,40),...metrics,transcript:Array.isArray(body.transcript)?body.transcript:[],swoc};
   if(!canSave)return NextResponse.json({session:{...data,id:0,createdAt:new Date()},swoc,persisted:false,message:"Guest interview scored; sign up to save history."});
   const [session]=await db.insert(interviewSessions).values(data).returning();return NextResponse.json({session,swoc,persisted:true},{status:201});
  }

  if(body.kind==="bookmark"){
   if(!body.question)return NextResponse.json({error:"Question is required"},{status:400});
   if(!canSave)return NextResponse.json({bookmark:null,persisted:false,message:"Sign up to save bookmarks."});
   const [bookmark]=await db.insert(bookmarks).values({userId,question:String(body.question),domain:String(body.domain||"").slice(0,120),company:String(body.company||"").slice(0,120)}).returning();return NextResponse.json({bookmark,persisted:true},{status:201});
  }
  return NextResponse.json({error:"Invalid request kind"},{status:400});
 }catch(error){
  console.error("Attempts write failure",error);
  return NextResponse.json({error:"Could not save progress. Please retry."},{status:500});
 }
}
