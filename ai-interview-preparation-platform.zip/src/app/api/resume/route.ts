import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { resumes } from "@/db/schema";
import { eq } from "drizzle-orm";

function calculateAts(content: Record<string, any>) {
  let score = 0;
  if (content.name?.trim()) score += 5;
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(content.email || "")) score += 5;
  if ((content.phone || "").replace(/\D/g, "").length >= 10) score += 5;
  if (content.linkedin?.trim()) score += 4;
  if (content.github?.trim() || content.portfolio?.trim()) score += 4;
  if ((content.summary || "").trim().split(/\s+/).length >= 25) score += 14;
  const skills = String(content.skills || "").split(",").filter(Boolean);
  score += Math.min(15, skills.length * 2);
  const projects = Array.isArray(content.projects) ? content.projects : [];
  score += Math.min(20, projects.filter((p: any) => p.name && p.description).length * 10);
  const education = Array.isArray(content.education) ? content.education : [];
  if (education.some((e: any) => e.degree && e.institute)) score += 12;
  const experience = Array.isArray(content.experience) ? content.experience : [];
  score += Math.min(10, experience.filter((e: any) => e.role && e.description).length * 5);
  if ((content.achievements || "").trim()) score += 6;
  return Math.min(100, score);
}

export async function GET(req: NextRequest) {
  try {
    const userId = Number(req.nextUrl.searchParams.get("userId") || 0);
    if (!userId) return NextResponse.json({ resume: null });
    const [resume] = await db.select().from(resumes).where(eq(resumes.userId, userId));
    return NextResponse.json({ resume: resume || null });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const userId = Number(body.userId || 0);
    if (!userId) return NextResponse.json({ error: "Create an account to save your resume" }, { status: 400 });
    const atsScore = calculateAts(body.content || {});
    const [existing] = await db.select().from(resumes).where(eq(resumes.userId, userId));
    const [resume] = existing
      ? await db.update(resumes).set({ title: body.title || "My Internship Resume", content: body.content || {}, atsScore, updatedAt: new Date() }).where(eq(resumes.userId, userId)).returning()
      : await db.insert(resumes).values({ userId, title: body.title || "My Internship Resume", content: body.content || {}, atsScore }).returning();
    return NextResponse.json({ resume, atsScore });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  const body = await req.json();
  return NextResponse.json({ atsScore: calculateAts(body.content || {}) });
}
