import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  const startedAt = Date.now();
  try {
    const result = await db.execute(sql`select current_database() as database, now() as server_time`);
    const row = result.rows[0] as { database?: string; server_time?: string } | undefined;
    return Response.json({
      ok: true,
      status: "healthy",
      service: "InterviewAce API",
      database: "connected",
      databaseName: row?.database || "postgresql",
      timestamp: new Date().toISOString(),
      latencyMs: Date.now() - startedAt,
      version: process.env.VERCEL_GIT_COMMIT_SHA?.slice(0, 7) || process.env.APP_VERSION || "local",
    }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (error) {
    console.error("Health check database failure", error);
    return Response.json({
      ok: false,
      status: "unhealthy",
      service: "InterviewAce API",
      database: "disconnected",
      error: "Database connection failed. Verify DATABASE_URL and run the schema deployment.",
      timestamp: new Date().toISOString(),
    }, { status: 503, headers: { "Cache-Control": "no-store, max-age=0" } });
  }
}
