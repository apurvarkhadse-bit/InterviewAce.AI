import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { agentMessages, assessmentAttempts, interviewSessions, resumes } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { COMPANIES, DOMAINS, MCQS, TESTS, HR_QUESTIONS, DOMAIN_INTERVIEW_Q, scoreAnswer } from "@/lib/data";

type Action={view:string;label:string;payload?:Record<string,string>};
const clean=(s:string)=>s.toLowerCase().trim();
function companyIn(text:string){return COMPANIES.find(c=>text.includes(c.name.toLowerCase())||text.includes(c.id));}
function domainIn(text:string){return DOMAINS.find(d=>text.includes(d.name.toLowerCase())||text.includes(d.id)||d.skills.some(s=>text.includes(s.toLowerCase())));}
function bullets(items:string[]){return items.map(x=>`• ${x}`).join("\n");}

async function reply(message:string,user:any,userId:number){
 const t=clean(message); const company=companyIn(t); const domain=domainIn(t);
 let action:Action|undefined; let suggestions:string[]=[]; let cards:any[]=[]; let answer="";
 const [tests,interviews,resumeRows]=userId?await Promise.all([
  db.select().from(assessmentAttempts).where(eq(assessmentAttempts.userId,userId)).orderBy(desc(assessmentAttempts.createdAt)).limit(10),
  db.select().from(interviewSessions).where(eq(interviewSessions.userId,userId)).orderBy(desc(interviewSessions.createdAt)).limit(10),
  db.select().from(resumes).where(eq(resumes.userId,userId)).limit(1)
 ]):[[],[],[]];
 const avgTest=tests.length?Math.round(tests.reduce((a,b)=>a+b.accuracy,0)/tests.length):0;
 const avgIv=interviews.length?Math.round(interviews.reduce((a,b)=>a+b.overallScore,0)/interviews.length):0;

 if(/^(hi|hello|hey|namaste|help)|what can you do/.test(t)){
  answer=`Hi ${user?.name?.split(" ")[0]||"there"}! I’m Ace AI — your placement copilot. I can:\n\n• Find company requirements and interview questions\n• Run mock interviews and recommend skill tests\n• Review your resume and improve its ATS score\n• Score a written interview answer\n• Build a personalised 7-day study plan\n• Explain technical, HR and aptitude concepts\n• Navigate you to any InterviewAce tool`;
  suggestions=["Make my 7-day plan","Review my resume","Prepare me for TCS","What should I practice today?"];
 } else if(t.includes("resume")||t.includes("ats")||t.includes("cv")){
  const r:any=resumeRows[0]; const score=r?.atsScore||0; const content:any=r?.content||{};
  const missing=[]; if(!content.summary)missing.push("professional summary"); if(!content.skills)missing.push("job-matched skills"); if(!content.projects?.some((p:any)=>p.name&&p.description))missing.push("2 quantified projects"); if(!content.linkedin)missing.push("LinkedIn URL");
  answer=r?`Your current ATS score is ${score}/100. ${score>=75?"Your base is strong — now tailor keywords for each job description.":"Let’s strengthen it before you apply."}\n\nPriority fixes:\n${bullets(missing.length?missing:["Add measurable results to project bullets","Use action verbs: Built, Improved, Automated","Tailor 8–12 skills to the target role"])}\n\nBest bullet formula: **Action + task + technology + measurable result**.`:`You haven’t saved a resume yet. I can guide you through an ATS-friendly one-page fresher resume. Start with profile, education, 2 projects, 8–12 skills and achievements.`;
  action={view:"resume",label:r?"Improve Resume":"Build Resume"}; suggestions=["Write my summary","Which skills should I add?","How do I describe a project?"];
 } else if(/plan|roadmap|practice today|what should i learn|prepare me/.test(t)){
  const d=domain||DOMAINS.find(x=>(user?.targetRole||"").toLowerCase().includes(x.name.split(" ")[0].toLowerCase()))||DOMAINS[0];
  const co=company||COMPANIES.find(x=>x.name===user?.targetCompany)||COMPANIES[0];
  answer=`Here’s your personalised 7-day plan for **${d.name} → ${co.name}**${avgTest||avgIv?` (current averages: tests ${avgTest}%, interviews ${avgIv}%)`:""}:\n\n1. ${d.roadmap[0]} + 20 aptitude questions\n2. ${d.roadmap[1]||d.topics[0]} + revise ${d.topics.slice(0,2).join(" & ")}\n3. Take a timed ${TESTS.find(x=>x.domain===d.name)?.title||"aptitude assessment"}\n4. Build/improve one project bullet using ${d.skills.slice(0,3).join(", ")}\n5. Practise 5 ${co.name} questions aloud in STAR format\n6. Complete a full company mock; target 70%+\n7. Review SWOC weaknesses and retry your lowest score\n\nDaily rule: 45 min learning + 20 min questions + 10 min speaking.`;
  action={view:"learn",label:`Open ${d.name} Roadmap`,payload:{domain:d.name}}; suggestions=[`Start ${co.name} mock`,`Show ${co.name} requirements`,`Test my ${d.name} skills`];
 } else if(company){
  answer=`**${company.name} preparation brief**\n${company.about}\n\nEligibility: ${company.cgpa}; ${company.backlogs}.\nPackage: ${company.salary} | Internship: ${company.stipend}\nRoles: ${company.roles.join(", ")}\n\nSkills to prioritise:\n${bullets(company.skillsRequired)}\n\nSelection flow:\n${company.rounds.map((r,i)=>`${i+1}. ${r.name} — ${r.desc}`).join("\n")}\n\nHigh-frequency question: “${company.questions[0]?.q}”`;
  action={view:"companies",label:`Open ${company.name} Vault`,payload:{company:company.name}}; cards=company.questions.slice(0,3).map(q=>({title:q.q,meta:`${q.type} • ${q.difficulty}`})); suggestions=[`Start ${company.name} mock`,`More ${company.name} questions`,`Am I eligible for ${company.name}?`];
 } else if(domain&&(/question|learn|skill|test|career|intern/.test(t))){
  const test=TESTS.find(x=>x.domain===domain.name);
  answer=`**${domain.name} career guide**\n${domain.description}\n\nTarget roles: ${domain.roles.join(", ")}\nTypical fresher range: ${domain.avgSalary} | Demand: ${domain.demand}%\nCore skills: ${domain.skills.join(", ")}\n\nRecommended order:\n${domain.roadmap.map((x,i)=>`${i+1}. ${x}`).join("\n")}\n\nInterview focus: ${domain.topics.join(", ")}`;
  action={view:test?"tests":"learn",label:test?`Take ${test.title}`:`Open ${domain.name} Roadmap`,payload:{domain:domain.name}}; suggestions=[`Mock interview for ${domain.name}`,`Questions for ${domain.name}`,"Make my 7-day plan"];
 } else if(/score my answer|review my answer|rate my answer/.test(t)){
  const raw=message.split(":").slice(1).join(":").trim(); const q=[...HR_QUESTIONS,...Object.values(DOMAIN_INTERVIEW_Q).flat()].find(q=>q.keywords.some(k=>clean(raw).includes(k.toLowerCase())))||HR_QUESTIONS[0]; const s=scoreAnswer(raw,q.keywords);
  answer=raw?`**Answer score: ${s.overall}/100**\n\n• Technical keywords: ${s.keywordScore}%\n• Fluency: ${s.fluency}%\n• Depth: ${s.lengthScore}% (${s.wordCount} words)\n• Fillers: ${s.fillerCount}\n• Matched: ${s.matched.join(", ")||"none yet"}\n• Add these: ${s.missed.join(", ")||"all target keywords covered"}\n\nImprove it with: definition → project/example → measurable result → learning.`:`Paste your answer after a colon. Example:\n“Score my answer: I used React virtual DOM and hooks in my project…”`;
  action={view:"interview",label:"Practise With Voice AI"}; suggestions=["How do I use STAR format?","Start mock interview"];
 } else if(/question|interview/.test(t)){
  const qs=domain?(DOMAIN_INTERVIEW_Q[domain.name]||[]):HR_QUESTIONS;
  answer=`Here are strong questions to practise${domain?` for ${domain.name}`:""}:\n\n${(qs.length?qs:HR_QUESTIONS).slice(0,5).map((q,i)=>`${i+1}. ${q.q}\n   Listen for: ${q.keywords.slice(0,5).join(", ")}`).join("\n\n")}\n\nSay each answer aloud for 45–90 seconds, then use the mock studio for NLP scoring.`;
  action={view:"questions",label:"Open Question Bank"}; suggestions=["Start mock interview","Explain STAR format","Score my answer:"];
 } else if(/aptitude|percentage|reasoning|nqt/.test(t)){
  const qs=MCQS.filter(x=>x.domain.includes("Aptitude")).slice(0,3); answer=`For placement aptitude, prioritise Percentages → Ratio → Time & Work → Speed & Distance → Series → Logical Reasoning.\n\nQuick practice:\n${qs.map((q,i)=>`${i+1}. ${q.q}`).join("\n")}\n\nTake the timed test before viewing explanations; target 80% accuracy with under 75 seconds/question.`;
  action={view:"tests",label:"Start Aptitude Test",payload:{test:"aptitude-grand"}}; suggestions=["TCS NQT pattern","Make aptitude plan"];
 } else if(/dashboard|open|go to|navigate/.test(t)){
  const map:[RegExp,string,string][]=[[/resume/,"resume","Open Resume Builder"],[/company/,"companies","Open Company Vault"],[/test|assessment/,"tests","Open Skill Tests"],[/interview|mock/,"interview","Open Mock Studio"],[/learn|roadmap/,"learn","Open Learn Hub"],[/swoc|analytics/,"swoc","Open SWOC"],[/question/,"questions","Open Questions"]]; const found=map.find(x=>x[0].test(t));
  answer=found?`I found the right workspace. Use the action below and I’ll take you there.`:`Tell me what you want to open: resume, test, interview, company vault, roadmap, SWOC or questions.`; if(found)action={view:found[1],label:found[2]};
 } else {
  answer=`I can help with that as your placement copilot. For the best answer, include a target role or company — for example:\n\n• “Prepare me for Infosys”\n• “Make a Web Development 7-day plan”\n• “Review my resume”\n• “Score my answer: [paste answer]”\n• “Give me AI/ML interview questions”`;
  suggestions=["What should I practice today?","Review my resume","Show company requirements","Start a mock interview"];
 }
 return {answer,action,cards,suggestions};
}

export async function GET(req:NextRequest){
 try{const userId=Number(req.nextUrl.searchParams.get("userId")||0); if(!userId)return NextResponse.json({messages:[]}); const messages=await db.select().from(agentMessages).where(eq(agentMessages.userId,userId)).orderBy(desc(agentMessages.createdAt)).limit(30); return NextResponse.json({messages:messages.reverse()});}catch{return NextResponse.json({messages:[]});}
}
export async function POST(req:NextRequest){
 try{const b=await req.json(); if(!b.message?.trim())return NextResponse.json({error:"Message required"},{status:400}); const result=await reply(b.message,b.user||{},Number(b.userId||0));
  if(b.userId){await db.insert(agentMessages).values([{userId:Number(b.userId),role:"user",content:b.message,metadata:{}},{userId:Number(b.userId),role:"assistant",content:result.answer,metadata:{action:result.action,cards:result.cards,suggestions:result.suggestions}}]);}
  return NextResponse.json(result);
 }catch(e:any){return NextResponse.json({error:e.message||"Agent unavailable"},{status:500});}
}
export async function DELETE(req:NextRequest){
 try{const b=await req.json();if(b.userId)await db.delete(agentMessages).where(and(eq(agentMessages.userId,Number(b.userId))));return NextResponse.json({ok:true});}catch{return NextResponse.json({ok:false},{status:500});}
}
