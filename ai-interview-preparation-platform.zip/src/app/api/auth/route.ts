import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { compare, hash } from "bcryptjs";

export const runtime = "nodejs";
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const safeUser = (user: typeof users.$inferSelect) => {
  const { password: _password, ...safe } = user;
  return safe;
};

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const action = String(body.action || "");
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");

    if (!emailPattern.test(email)) return NextResponse.json({ error: "Enter a valid email address" }, { status: 400 });
    if (password.length < 8) return NextResponse.json({ error: "Password must contain at least 8 characters" }, { status: 400 });

    if (action === "signup") {
      const name = String(body.name || "").trim();
      if (name.length < 2) return NextResponse.json({ error: "Enter your full name" }, { status: 400 });
      const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
      if (existing) return NextResponse.json({ error: "Account already exists — please login" }, { status: 409 });
      const passwordHash = await hash(password, 12);
      const [created] = await db.insert(users).values({
        name: name.slice(0, 120), email, password: passwordHash,
        branch: String(body.branch || "Computer Science / IT").slice(0, 80),
        targetRole: String(body.targetRole || "Web Development Intern").slice(0, 120),
        college: String(body.college || "").slice(0, 180), year: String(body.year || "3rd Year").slice(0, 40),
        targetCompany: String(body.targetCompany || "TCS").slice(0, 80),
      }).returning();
      return NextResponse.json({ user: safeUser(created) }, { status: 201 });
    }

    if (action === "login") {
      const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
      if (!user) return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
      // Supports old plaintext development accounts once, then transparently upgrades them.
      const hashed = user.password.startsWith("$2");
      const valid = hashed ? await compare(password, user.password) : password === user.password;
      if (!valid) return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
      if (!hashed) await db.update(users).set({ password: await hash(password, 12) }).where(eq(users.id, user.id));
      return NextResponse.json({ user: safeUser(user) });
    }

    return NextResponse.json({ error: "Invalid authentication action" }, { status: 400 });
  } catch (error) {
    console.error("Authentication API failure", error);
    return NextResponse.json({ error: "Authentication service unavailable. Please try again." }, { status: 500 });
  }
}
