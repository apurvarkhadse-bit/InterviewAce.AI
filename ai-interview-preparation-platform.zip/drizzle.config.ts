import { config } from "dotenv";
import { defineConfig } from "drizzle-kit";

config({ path: ".env.local" });
config();
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required for Drizzle migrations");

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  dbCredentials: { url: process.env.DATABASE_URL },
  strict: true,
  verbose: true,
});
